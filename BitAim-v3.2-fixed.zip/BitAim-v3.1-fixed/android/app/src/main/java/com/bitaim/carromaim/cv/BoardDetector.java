package com.bitaim.carromaim.cv;

import android.graphics.Bitmap;
import android.graphics.PointF;
import android.graphics.RectF;
import android.util.Log;

import org.opencv.android.Utils;
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.MatOfPoint;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;

import java.util.ArrayList;
import java.util.List;

/**
 * BoardDetector  v3.2 — tuned for the Carrom pool game screenshots:
 *
 *  Board area: light tan/beige wooden surface
 *  Border:     bright ORANGE frame (very distinctive)
 *  Background: dark red/maroon (outside the board)
 *  Coins:      black, white (cream), red queen, blue striker
 *
 * Detection pipeline:
 *  1. Find orange border → bounding rect = board
 *  2. HoughCircles inside board region only
 *  3. Classify each circle by HSV color
 *  4. Striker = blue (hue ~100-130, high sat) OR largest in lower 40%
 */
public class BoardDetector {

    private static final String TAG      = "BoardDetector";
    private static final int    PROC_W   = 540; // wider for better circle detection

    // Tunables
    private float  minRadiusFrac = 0.018f;  // relative to proc width
    private float  maxRadiusFrac = 0.060f;
    private double param2        = 16;       // lower = more sensitive

    // Reusable Mats
    private final Mat frame  = new Mat();
    private final Mat small  = new Mat();
    private final Mat gray   = new Mat();
    private final Mat hsv    = new Mat();

    public void setMinRadiusFrac(float v) { minRadiusFrac = Math.max(0.008f, Math.min(v, 0.06f)); }
    public void setMaxRadiusFrac(float v) { maxRadiusFrac = Math.max(0.025f, Math.min(v, 0.12f)); }
    public void setParam2(double v)       { param2        = Math.max(6,      Math.min(v, 50));    }

    public synchronized GameState detect(Bitmap bitmap) {
        if (bitmap == null) return null;
        int srcW = bitmap.getWidth();
        int srcH = bitmap.getHeight();
        if (srcW == 0 || srcH == 0) return null;

        // ── Resize for processing ────────────────────────────────────────────
        Utils.bitmapToMat(bitmap, frame);
        float scale = (float) PROC_W / srcW;
        int   procH = Math.round(srcH * scale);
        Imgproc.resize(frame, small, new Size(PROC_W, procH), 0, 0, Imgproc.INTER_AREA);

        // Build HSV + gray versions
        Imgproc.cvtColor(small, hsv, Imgproc.COLOR_RGBA2BGR);
        Imgproc.cvtColor(hsv, hsv, Imgproc.COLOR_BGR2HSV);
        Imgproc.cvtColor(small, gray, Imgproc.COLOR_RGBA2GRAY);
        Imgproc.GaussianBlur(gray, gray, new Size(5, 5), 1.2);

        // ── 1. Detect board from orange border ───────────────────────────────
        RectF board = detectBoardFromOrangeBorder(PROC_W, procH, scale, srcW, srcH);

        // ── 2. Detect circles ────────────────────────────────────────────────
        List<Coin> all = detectCircles(PROC_W, procH, scale, board);

        // ── 3. Classify striker ──────────────────────────────────────────────
        GameState state = new GameState();
        Coin striker = pickStriker(all, srcH);

        if (striker != null) {
            striker.isStriker = true;
            striker.color = Coin.COLOR_STRIKER;
            state.striker = striker;
            for (Coin c : all) {
                if (c != striker) state.coins.add(c);
            }
        } else {
            state.coins.addAll(all);
        }

        // ── 4. Board rect ────────────────────────────────────────────────────
        if (board != null && board.width() > srcW * 0.25f) {
            state.board = board;
        } else {
            state.board = inferBoardFromCoins(all, srcW, srcH);
        }

        // ── 5. Pockets at board corners ──────────────────────────────────────
        placePockets(state);

        Log.d(TAG, "Detected " + all.size() + " circles, striker=" + (striker != null)
                + ", board=" + state.board);
        return state;
    }

    // ── Orange border detection ──────────────────────────────────────────────

    /**
     * The carrom game has a VERY bright orange border (H≈8-25, S≈180-255, V≈160-255).
     * This is far more reliable than detecting the wooden frame color.
     */
    private RectF detectBoardFromOrangeBorder(int procW, int procH, float scale, int srcW, int srcH) {
        try {
            // Orange: hue 8-25 in OpenCV (0-180 range), high saturation, high value
            Mat orange = new Mat();
            Core.inRange(hsv,
                    new Scalar(8,  150, 140),
                    new Scalar(25, 255, 255),
                    orange);

            // Morphological ops to connect the border into one solid region
            Mat kernel = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, new Size(12, 12));
            Imgproc.morphologyEx(orange, orange, Imgproc.MORPH_CLOSE,  kernel);
            Imgproc.morphologyEx(orange, orange, Imgproc.MORPH_DILATE, kernel);

            List<MatOfPoint> contours = new ArrayList<>();
            Mat hier = new Mat();
            Imgproc.findContours(orange, contours, hier,
                    Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE);

            // Largest contour by area = the board border
            double maxArea = 0;
            Rect   best    = null;
            for (MatOfPoint cnt : contours) {
                double area = Imgproc.contourArea(cnt);
                if (area > maxArea) {
                    maxArea = area;
                    best    = Imgproc.boundingRect(cnt);
                }
            }

            orange.release(); kernel.release(); hier.release();

            // Need at least 20% of frame area to be valid
            if (best == null || maxArea < procW * procH * 0.08) return null;

            // Scale back to source coords
            float l = best.x / scale;
            float t = best.y / scale;
            float r = (best.x + best.width)  / scale;
            float b = (best.y + best.height) / scale;

            // Force square (carrom board is square) centred on detected rect
            float cx   = (l + r) / 2f;
            float cy   = (t + b) / 2f;
            float side = Math.max(r - l, b - t);
            // Add small padding to include the full border
            side *= 1.02f;
            RectF result = new RectF(cx - side/2f, cy - side/2f, cx + side/2f, cy + side/2f);

            // Clamp to screen
            if (result.left   < 0)    result.left   = 0;
            if (result.top    < 0)    result.top    = 0;
            if (result.right  > srcW) result.right  = srcW;
            if (result.bottom > srcH) result.bottom = srcH;
            return result;

        } catch (Exception e) {
            Log.w(TAG, "Orange border detect failed: " + e.getMessage());
            return null;
        }
    }

    // ── Circle detection ─────────────────────────────────────────────────────

    private List<Coin> detectCircles(int procW, int procH, float scale, RectF board) {
        int minR    = Math.round(procW * minRadiusFrac);
        int maxR    = Math.round(procW * maxRadiusFrac);
        int minDist = (int) (minR * 1.5f);

        // Try 3 sensitivity levels and pick the one with most plausible results
        double[] thresholds = { param2, param2 * 0.80, param2 * 0.65 };
        List<Coin> best = new ArrayList<>();

        for (double thresh : thresholds) {
            Mat c = new Mat();
            Imgproc.HoughCircles(gray, c, Imgproc.HOUGH_GRADIENT,
                    1.0,        // dp — ratio of accumulator res to image res
                    minDist,
                    80,         // Canny high threshold
                    thresh,     // accumulator threshold (lower = more circles)
                    minR, maxR);

            List<Coin> found = parseCircles(c, scale, board);
            c.release();
            // Accept result with more coins, up to 30
            if (found.size() > best.size() && found.size() <= 30) {
                best = found;
            }
        }
        return best;
    }

    private List<Coin> parseCircles(Mat c, float scale, RectF board) {
        List<Coin> list = new ArrayList<>();
        if (c.empty()) return list;
        for (int i = 0; i < c.cols(); i++) {
            double[] d = c.get(0, i);
            if (d == null || d.length < 3) continue;
            float cx = (float) d[0];
            float cy = (float) d[1];
            float cr = (float) d[2];

            // Skip if circle center is clearly outside the board in proc coords
            if (board != null) {
                float screenX = cx / scale;
                float screenY = cy / scale;
                float margin  = cr / scale * 2f;
                if (screenX < board.left  - margin || screenX > board.right  + margin) continue;
                if (screenY < board.top   - margin || screenY > board.bottom + margin) continue;
            }

            int color = classifyColor((int) cx, (int) cy, (int) cr);
            if (color < 0) continue;
            list.add(new Coin(cx / scale, cy / scale, cr / scale, color, false));
        }
        return list;
    }

    // ── Color classifier ─────────────────────────────────────────────────────
    // Tuned for this specific carrom game's color palette

    private int classifyColor(int x, int y, int r) {
        if (r < 3) return -1;
        int rows = hsv.rows(), cols = hsv.cols();
        if (x - r < 0 || y - r < 0 || x + r >= cols || y + r >= rows) return -1;

        // Sample inner 50% of radius for robust classification
        int s  = Math.max(2, (int)(r * 0.50f));
        int y0 = Math.max(0, y - s), y1 = Math.min(rows-1, y+s);
        int x0 = Math.max(0, x - s), x1 = Math.min(cols-1, x+s);
        if (y1 <= y0 || x1 <= x0) return -1;

        Mat   patch = hsv.submat(y0, y1, x0, x1);
        org.opencv.core.Scalar mean = Core.mean(patch);
        patch.release();

        double h   = mean.val[0]; // 0..180 in OpenCV
        double sat = mean.val[1]; // 0..255
        double val = mean.val[2]; // 0..255

        // ── Blue striker (distinctly blue) ────────────────────────────────
        // H ≈ 100-130, high sat, medium-high val
        if (h >= 95 && h <= 135 && sat > 100 && val > 60) return Coin.COLOR_STRIKER;

        // ── Black coin: very dark ─────────────────────────────────────────
        if (val < 80) return Coin.COLOR_BLACK;

        // ── Red queen: saturated red/orange-red ───────────────────────────
        // H near 0 or near 180, OR orange-red H 0-10
        if (sat > 100 && val > 80) {
            if (h < 12 || h > 165) return Coin.COLOR_RED;
        }

        // ── White coin: bright, low saturation ───────────────────────────
        if (val > 150 && sat < 90) return Coin.COLOR_WHITE;

        // ── Reject board surface (tan/beige) ─────────────────────────────
        // The playing surface: H ~15-35, moderate sat, medium val
        if (h > 12 && h < 38 && sat < 130 && val > 100 && val < 230) return -1;

        // ── Reject orange border pieces ───────────────────────────────────
        if (h >= 8 && h <= 28 && sat > 140 && val > 130) return -1;

        // ── Reject dark red background ────────────────────────────────────
        if (val < 110 && sat > 60 && (h < 15 || h > 160)) return -1;

        return -1;
    }

    // ── Striker picker ───────────────────────────────────────────────────────

    private Coin pickStriker(List<Coin> all, int srcH) {
        // First priority: find the blue coin (Coin.COLOR_STRIKER from classifier)
        for (Coin c : all) {
            if (c.color == Coin.COLOR_STRIKER) return c;
        }
        // Fallback: largest white-ish coin in lower 50% of screen
        Coin best      = null;
        float bestScore = -1;
        for (Coin c : all) {
            if (c.color != Coin.COLOR_WHITE) continue;
            float yFrac = c.pos.y / (float) srcH;
            if (yFrac < 0.45f) continue; // must be in lower half
            float score = c.radius * (0.2f + 0.8f * yFrac);
            if (score > bestScore) { bestScore = score; best = c; }
        }
        return best;
    }

    // ── Board inference fallback ─────────────────────────────────────────────

    private RectF inferBoardFromCoins(List<Coin> all, int w, int h) {
        if (all.size() < 2) {
            // Default: 88% wide, centered at 48% down
            float side = w * 0.88f;
            float cx = w / 2f, cy = h * 0.48f;
            return new RectF(cx-side/2f, cy-side/2f, cx+side/2f, cy+side/2f);
        }
        float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE;
        float maxX = -Float.MAX_VALUE, maxY = -Float.MAX_VALUE;
        for (Coin c : all) {
            if (c.pos.x < minX) minX = c.pos.x;
            if (c.pos.y < minY) minY = c.pos.y;
            if (c.pos.x > maxX) maxX = c.pos.x;
            if (c.pos.y > maxY) maxY = c.pos.y;
        }
        float pad  = Math.max(40f, (maxX - minX) * 0.12f);
        float side = Math.max(maxX - minX, maxY - minY) + pad * 2f;
        float cx   = (minX + maxX) / 2f;
        float cy   = (minY + maxY) / 2f;
        RectF r = new RectF(cx-side/2f, cy-side/2f, cx+side/2f, cy+side/2f);
        if (r.left < 0)  r.left = 0;
        if (r.top  < 0)  r.top  = 0;
        if (r.right  > w) r.right  = w;
        if (r.bottom > h) r.bottom = h;
        return r;
    }

    // ── Pocket placement ─────────────────────────────────────────────────────

    private void placePockets(GameState s) {
        // Pockets are at the 4 corners, inset ~5% from the board edge
        float inset = s.board.width() * 0.05f;
        s.pockets.add(new PointF(s.board.left  + inset, s.board.top    + inset));
        s.pockets.add(new PointF(s.board.right - inset, s.board.top    + inset));
        s.pockets.add(new PointF(s.board.left  + inset, s.board.bottom - inset));
        s.pockets.add(new PointF(s.board.right - inset, s.board.bottom - inset));
    }
}
